******* Download and Install Pycharm 1.3 ******
www.https://www.jetbrains.com/pycharm/download/other.html
******* PyStarEEGLab Installation ******

clone py_stareeglab
Run --> pip install -r requirements.txt
Run --> python setup.py install

******* DemoOdors Installation **********

clone DemoOdors
Open a new project with an empty environment
Run --> pip install -r requirements.txt

******* Launch Feature Extractor ********
Run Feature_Extractor.py
******* Launch Demo Feedback ******
Run APP.py